#!/bin/sh

xterm -e "roslaunch my_robot usinani_turtlebot.launch" &
sleep 5
xterm -e "roslaunch my_robot amcl_demo.launch" &
sleep 5
xterm -e "roslaunch turtlebot_rviz_launchers view_navigation.launch" &
sleep 5

