#!/bin/sh

# Turtle bot
xterm -e "roslaunch my_robot usinani_turtlebot.launch" &
sleep 5
# AMCL
xterm -e "roslaunch my_robot amcl_and_map.launch" &
sleep 5
# rviz
xterm -e "roslaunch turtlebot_rviz_launchers view_navigation.launch" &
sleep 5
# add_markers
xterm -e "rosrun add_markers add_markers" &

